package com.scamguardja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScamguardJaApplicationTests {

	@Test
	void contextLoads() {
	}

}
